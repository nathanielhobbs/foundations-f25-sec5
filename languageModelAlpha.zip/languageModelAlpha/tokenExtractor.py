import sys

def tokenExtractor(lines):
    tokens = []
    for s in lines:
        tokens.extend(s.split())
    return tokens

print(sys.argv)
if len(sys.argv) > 1:
    file_name = sys.argv[1]
else:
    file_name = 'languageModelAlpha/fish.txt'

with open(file_name, 'r') as f:
    lines = f.readlines()

tokens = tokenExtractor(lines)
