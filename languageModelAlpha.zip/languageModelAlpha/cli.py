# import sys

# print(sys.argv)
# if len(sys.argv) > 1:
#     file_name = sys.argv[1]
# else:
#     file_name = 'languageModelAlpha/fish.txt'

import argparse

parser = argparse.ArgumentParser()
parser.add_argument('filename', nargs='?', default='languageModelAlpha/fish.txt')
args = parser.parse_args()

file_name = args.filename