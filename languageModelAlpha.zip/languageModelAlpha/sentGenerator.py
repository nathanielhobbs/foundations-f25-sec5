import random
from .tokenExtractor import tokens

def genSentence():
    sentence = []
    while len(sentence) < 50:
        tok = random.choice(tokens)
        sentence.append(tok)
        if tok == '.':
            break
    else:
        sentence.append('.')

    return " ".join(sentence)