import randname

print(randname.nickname())