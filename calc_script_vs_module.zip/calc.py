author = "Alice"

def sum(a,b,*args):
    return_val = a+b
    for arg in args:
        return_val += arg
    
    return return_val

# print('sum(3,4) is ' + str(sum(3,4)))
# print(f'sum(3,4) is {sum(3,4,56)}')

# exit()

def product(a,b,*args):
    return_val = a*b
    for arg in args:
        return_val *= arg
    
    return return_val

if __name__ == '__main__':
    print(f'{sum(3,4)=}')
    print(f'{sum(3,4,5,6,7,8)=}')
    print(f'{product(3,4)=}')
    print(f'{product(3,4,5,6,7,8)=}')
