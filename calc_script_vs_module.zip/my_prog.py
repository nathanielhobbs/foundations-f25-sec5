from calc import sum, product
from calc import author as calc_author

author = "Bob"

print(author)
print(calc_author)
print(sum(8,8))
print(product(8,8))


# import calc

# print(calc.author)
# print(calc.sum(8,8))
# print(calc.product(8,8))



# from calc import sum, product

# print(sum(8,8))
# print(product(8,8))



# import calc

# print(calc.author)
# print(calc.sum(8,8))
# print(calc.product(8,8))

# import calc as c

# print(c.author)
# print(c.sum(8,8))
# print(c.product(8,8))