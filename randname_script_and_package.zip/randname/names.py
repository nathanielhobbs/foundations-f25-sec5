ADJ = ['pretty', 'silly', 'wonderful']
NOUN = ['fox', 'bear', 'coyote', 'snake', 'flamingo']