import random
from .names import ADJ, NOUN # names has a . in front b/c it's a part of the same module

def nickname(sep: str = "-") -> str:
    if not isinstance(sep, str):
        raise TypeError("sep must be a string.")
    
    return f"{random.choice(ADJ)}{sep}{random.choice(NOUN)}"