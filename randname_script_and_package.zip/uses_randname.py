from randname.gen import nickname

print(nickname())